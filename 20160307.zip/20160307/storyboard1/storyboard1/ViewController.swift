//
//  ViewController.swift
//  storyboard1
//
//  Created by n135 on 2016/3/7.
//  Copyright © 2016年 n135. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var btn:UIButton!;
    @IBOutlet var slider:UISlider!;
    @IBOutlet var switch1:UISwitch!;
    @IBOutlet var stepper:UIStepper!;
    @IBOutlet var textField:UITextField!;
    @IBOutlet var alertAction:UITextField!;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(btn.frame);

        btn.addTarget(self, action: "userClick:", forControlEvents: UIControlEvents.TouchUpInside);
        slider.addTarget(self, action: "userSlider:", forControlEvents: UIControlEvents.ValueChanged);
        switch1.addTarget(self, action: "userSwitch:", forControlEvents: UIControlEvents.ValueChanged);
        stepper.addTarget(self, action: "userStepper:", forControlEvents: UIControlEvents.ValueChanged);
        textField.addTarget(self, action: "userChanged:", forControlEvents: UIControlEvents.EditingChanged);
        self.alertAction("錯誤提示", msg: "請輸入");
        

        
    }
    
    func userClick ( sender : UIButton ){
        print("userClick");
    }
    
    func userSlider ( sender : UISlider ){
        print("slider\(sender.value)");
    }
    
    func userStepper ( sender : UIStepper ){
        print("slider\(sender.value)");
    }
    
    func userSwitch (sender :UISwitch){
        if sender.on {
            print("Open");
        }else{
            print("Close");
        }
    }
    
    func userChanged ( sender : UITextField ){
        print("slider\(sender.text!)");
    }


    
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

