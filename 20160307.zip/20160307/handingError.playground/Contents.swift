//: Playground - noun: a place where people can play

import UIKit

enum VendingMachineError:ErrorType{
    case InvalidSelection;
    case InsufficientFunds(coinsNeeded:Int);
    case OutOfStock;
}

struct Item{
    var price:Int;
    var count:Int;
}

class VendingMachine{
    var inventory = [
        "Candy Bar":Item(price: 12, count: 7),
        "Chips":Item(price: 10, count: 4),
        "Pretzels":Item(price: 7, count: 11)
    ];
    
    var coinsDeposited = 0;
    
    func dispenseSnack(snack:String){
        print("Dispensing \(snack)");
    }
    
    func vend(intemNamed name:String)throws{
        guard var item = inventory[name] else{
            throw VendingMachineError.InvalidSelection;
        }
        
        guard item.count > 0 else{
            throw VendingMachineError.OutOfStock;
        }
        
        guard item.price <= coinsDeposited else{
            throw VendingMachineError.InsufficientFunds(coinsNeeded: item.price - coinsDeposited);
        }
        
        coinsDeposited -= item.price;
        --item.count;
        
        inventory[name] = item;
        
        dispenseSnack(name);
    }
    
    
}

var vendingMachine = VendingMachine();
vendingMachine.coinsDeposited = 8;
//檢查錯誤的第一種方法do,try,catch
do{
    try vendingMachine.vend(intemNamed: "Candy Bar");
}catch VendingMachineError.InvalidSelection{
    print("Invalid Selection");
}catch VendingMachineError.OutOfStock{
    print("out of stock");
}catch VendingMachineError.InsufficientFunds(let coinsNeeded){
    print("不足\(coinsNeeded)");
}


//檢查錯誤使用try?會傳出nil
if (try? vendingMachine.vend(intemNamed: "Candy Bar")) == nil {
    print("發生錯誤");
}

//檢查錯誤使用try!，保證一定不會有錯，不用檢查

//使用throws的function
func abc()throws{
    try vendingMachine.vend(intemNamed: "Candy Bar");
}




